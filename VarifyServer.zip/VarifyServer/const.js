let code_prefix = "code_";
const Errors = {
    Success: 0,
    RedisErr: 1,
    Exception: 2,
};
module.exports = { code_prefix, Errors };